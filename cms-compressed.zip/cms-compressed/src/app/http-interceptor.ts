import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpResponse,
  HttpErrorResponse,
  HttpHandler,
  HttpEvent
} from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { AuthCookie } from './authentication/services/auth-cookie.service';

@Injectable()
export class CustomHttpInterceptor implements HttpInterceptor {

  constructor(
    private _authCookie: AuthCookie
    ) { }
    // token:string = localStorage.getItem("Token");
    // userId:string=localStorage.getItem("UserId");
    
    debugger;
    token="";
    userId="";
    token_value:string = "";
    userid_value:string = "";
    us="";
    
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
  debugger;
    this.token=this._authCookie.getAuth()!=null?JSON.parse(atob(this._authCookie.getAuth())).Token:null;
    this.userId=this._authCookie.getAuth()!=null?JSON.parse(atob(this._authCookie.getAuth())).UserId:null;
    this.token_value= this.token;
    this.userid_value = this.userId;
    this.us=`Bearer ${this.token_value}`;

    const customReq = request.clone({
        setHeaders: {
            //Authorization: `Bearer ${this.auth.getToken()}`
            'Authorization': `Bearer ${this.token_value}`,
            'UserId':`${this.userid_value}`
          }
      //headers: request.headers.set('app-language', 'it')
    });

    return next
      .handle(customReq)
      .do((ev: HttpEvent<any>) => {
        if (ev instanceof HttpResponse) {
          console.log('processing response', ev);
        }
      })
      .catch(response => {
        if (response instanceof HttpErrorResponse) {
          console.log('Processing http error', response);
        }

        return Observable.throw(response);
      });
  }
}
