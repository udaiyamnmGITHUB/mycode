import { Component,OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../authentication/services/auth.service';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';


@Component({
  selector: 'login',
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})

export class LoginComponent implements OnInit{
  
  formGroup: FormGroup;
  username ;  
  password;
  invalidCredentialMsg;
  public loginLoader = false;
  
   ngOnInit() {
     this.formGroup = new FormGroup({
      username: new FormControl('', [
         Validators.required,
         Validators.minLength(8)
       ]),
       password: new FormControl('', [
         Validators.required,
         Validators.minLength(8),
         //Validators.maxLength(20)
       ])
     });
    
   }
 
  
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService
  ) {

  }
    // get return url from route parameters or default to '/'
    returnUrl = '/home/app';
  

  login() {
    this.loginLoader = true;
    let uname = this.username;
    let pwd = this.password;
    setTimeout(function() {
    this.authService.isUserAuthenticated(this.username, this.password).subscribe(
        authenticated => {
          this.loginLoader = false;
          if(authenticated) {
              let url =  this.authService.getRedirectUrl(); 
              this.router.navigate([ url ]);					  
        } else {
           this.invalidCredentialMsg = 'Invalid Credentials. Try again.';
        }
      }
    );
  }.bind(this), 500);
  }
}
