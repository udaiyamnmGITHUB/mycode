
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';
import { HTTP_INTERCEPTORS,HttpClientModule,HttpClient } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgBootstrapFormValidationModule } from 'ng-bootstrap-form-validation';
import { StudyModule } from './maincontent/studymodule/study-module';


import { AppRoutingModule } from './app-routing.module';
import { AppMaterialModule } from './app-material.module';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';


import { LoaderService } from './loader.service';
import { AuthService } from './authentication/services/auth.service';
import { AuthCookie } from './authentication/services/auth-cookie.service';
import { HomeService } from './home.service';
import { AuthGuardService } from './authentication/services/auth-guard.service';
import { Globals } from './globals';
import { CustomHttpInterceptor } from './http-interceptor';

import { routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidebarComponent,
    FooterComponent,
    LoginComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpModule,
    FormsModule,
    AppRoutingModule,
    StudyModule,
    FormsModule,
    ReactiveFormsModule,
    AppMaterialModule,
    HttpClientModule,
    LoadingModule.forRoot({
      animationType: ANIMATION_TYPES.threeBounce,
      backdropBackgroundColour: 'rgba(0,0,0,0.1)',
      backdropBorderRadius: '14px',
      primaryColour: '#3c8dbc',
      secondaryColour: '#3c8dbc',
      tertiaryColour: '#3c8dbc',
      fullScreenBackdrop: false
    })
  ],
  providers: [LoaderService, AuthService, AuthGuardService, HomeService, Globals,AuthCookie,
    { provide: HTTP_INTERCEPTORS, useClass: CustomHttpInterceptor, multi: true }  
  ],
  bootstrap: [HomeComponent],
})
export class AppModule { }


