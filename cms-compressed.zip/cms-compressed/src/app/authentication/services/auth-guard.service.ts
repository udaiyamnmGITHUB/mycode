import { Injectable }       from '@angular/core';
import { CanActivate, CanActivateChild, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService }      from './auth.service';

@Injectable()
export class AuthGuardService implements CanActivate, CanActivateChild {
  	
  constructor(private authService: AuthService, private router: Router) {
  }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
	let loggedInUser= this.authService.getLoggedInUser();
	//let url: string = state.url;
	//console.log('Url:'+ url);
	if (this.authService.isUserLoggedIn() && loggedInUser.role == 'ADMIN') {
		return true; 
	}
	else{
		this.router.navigate([ this.authService.getunauthUrl() ]);	
	}
	/* if (this.authService.isUserLoggedIn() && loggedInUser.role == 'ADMIN') {
		this.router.navigate([ this.authService.getUrl() ]);
		return false;
	      } */
        //this.authService.setRedirectUrl(url);
        //this.router.navigate([ this.authService.getauthUrl() ]);
	return false;
  }
  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        let loggedInUser= this.authService.getLoggedInUser();
	if (loggedInUser.role === 'ADMIN') {
	        return true;		
	} 
	else {
		this.router.navigate([ this.authService.getunauthUrl() ]);
	}
  }  
}