import { Component, OnInit } from '@angular/core';
import { HomeService } from './home.service';
import { Router, ActivatedRoute } from '@angular/router';
//import {LocalStorage, SessionStorage} from "angular-localstorage";
import { Globals } from './globals';
import { LoaderService } from './loader.service';
import { AuthCookie } from './authentication/services/auth-cookie.service';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls:['./loader.component.css']
})  

export class HomeComponent {
  showLoader: boolean;
  private redirectUrl: string = '/home/app/study';

  constructor(
    private _ADAuthService: HomeService, 
    private router: Router,
    private _globals:Globals,
    private _authCookie: AuthCookie
    ) { }

  ngOnInit() {   
     
    this._ADAuthService.isUserAuthenticated().subscribe(res => {
      res = JSON.parse(res);
      if (res.IsAuthenticated) {
        
        //localStorage.setItem("Name",res.FullName);
        // localStorage.setItem("UserId",res.UserId);
        // localStorage.setItem("Token",res.Token);
        //res.FullName=btoa(res.FullName);

        var encode=btoa(JSON.stringify({"Name":res.FullName, "UserId":res.UserId,"Token":res.Token}));
        this._authCookie.setAuth(encode);
      
        var decode=this._authCookie.getAuth();
        decode=JSON.parse(atob(decode)).Name;
        var fullName=decode;
        this._globals.fullname=fullName;
        let url = this.redirectUrl;
        this.router.navigate([url]);
      } else {
        this.router.navigate(['/home/login']);
      }
     
    });
    
  }
  
}

