import { Component } from '@angular/core';

@Component({
  template: `<section class="content-header">
 
  <img src="../../assets/img/under_construction.gif" style="height:850px">
  
</section>`
})
export class UnderDevComponent {

}
