import { HttpClient, HttpResponse,  HttpHeaders  } from '@angular/common/http';
import {RequestOptions,ResponseContentType,Headers } from '@angular/http'; 
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class ReportsService {
    constructor(private http: HttpClient) { }


    private redirectUrl:string='/home/app/choose-report';
    private reportUrl:string='/home/app/report-parameter';
    private property = new RequestOptions({ withCredentials: true });

    downloadPDF(reportsInputObj): any {
        let headers = new Headers({ 
           
         });
         let options = new RequestOptions({ headers: headers,withCredentials: true  });
         // Ensure you set the responseType to Blob.
       // options.responseType = ResponseContentType.Blob;
        return this.http.post("http://dfwdw0app022.ent.covance.com:3888/api/reports/GetPdfReport",reportsInputObj,{responseType: 'blob' as 'blob'}).map(
        (res) => {
            let fileBlob = res;
            let blob = new Blob([fileBlob], { 
               type: 'application/pdf' // must match the Accept type
            });
            return blob;
        }); 
    }

    downloadXLS(reportsInputObj): any {
        let headers = new Headers({ 
            //'Content-Type': 'application/json', 
           // 'Accept': 'application/pdf'
         
         });
         let options = new RequestOptions({ headers: headers,withCredentials: true  });
         // Ensure you set the responseType to Blob.
        // options.responseType = ResponseContentType.Blob;
        return this.http.post("http://dfwdw0app022.ent.covance.com:3888/api/reports/GetXlsReport",reportsInputObj,{responseType: 'blob' as 'blob'}).map(
        (res) => {
            let fileBlob = res;
            let blob = new Blob([fileBlob], { 
               type: 'application/vnd.ms-excel' // must match the Accept type
            });
            return blob;
        });
    }

    downloadRTF(reportsInputObj): any {
        let headers = new Headers({ 
            //'Content-Type': 'application/json', 
           // 'Accept': 'application/pdf'
         });
         let options = new RequestOptions({ headers: headers,withCredentials: true  });
         // Ensure you set the responseType to Blob.
        // options.responseType = ResponseContentType.Blob;
        return this.http.post("http://dfwdw0app022.ent.covance.com:3888/api/reports/GetRtfReport",reportsInputObj,{responseType: 'blob' as 'blob'}).map(
        (res) => {
            let fileBlob = res;
            let blob = new Blob([fileBlob], { 
               type: 'text/html' // must match the Accept type
            });
            return blob;
        });
    }

    getRedirectUrl(): string {
       
		return this.redirectUrl;
	}
	setRedirectUrl(url: string): void {
		this.redirectUrl = url;
    }
    
    getReportUrl(): string {
        
         return this.reportUrl;
     }
     setReportUrl(url: string): void {
         this.reportUrl = url;
     }
}