import { Component, OnInit, OnChanges, SimpleChange} from '@angular/core';
import { StudyService } from '../study.service';
import { LoadingModule,ANIMATION_TYPES } from 'ngx-loading';

@Component({
  selector:'study-detail',
  templateUrl: './study-detail.html'
})
export class StudyDetailComponent{

  disabled:boolean;
  studyDetailDD=[];
  studyDetail=[];
  public studyDetailLoader = false;

  constructor(private _studySevice:StudyService){} 

  AssignStudydetails(resStudyDetails){  
    this.studyDetailDD=resStudyDetails;
    this.studyDetail=resStudyDetails[0];
    this.disabled=true;
  }

 getStudyDetails(studyNumber){ 
 
    this.studyDetailLoader = true;  
    this._studySevice.getStudyDetails(studyNumber).subscribe(resStudy=>{
      this.studyDetailLoader = false;
      this.AssignStudydetails(resStudy)
  }); 
 }

 onReset()
 {
  this.studyDetailDD=[];
  this.studyDetail=[];
 }

 }
   
