function offcialLtrController($scope, $http, $window, $modal) {

	$('#loading').show();

	$scope.notification = true;
	$scope.notice = {};
	$scope.notice.bucketType = 'offLetters';

	$scope.closeNotice = function(notice) {
		$scope.notification = !notice;

	};
	$http.post('rest/getNotifications', $scope.notice).error(function(data) {
		$('#loading').hide();
	}).success(function(data) {
		$('#loading').hide();
		$scope.notice = data;
		if ($scope.notice.flag == 'N') {
			$scope.notification = false;
		} else {
			$scope.notice.notice = $scope.notice.notice;
		}

	});

	var datepicker = $("#datepickerfy");
	$scope.noLetter = false;
	$scope.offLtr = {};
	$scope.showpopup = false;

	// Get Max Fin Year
	$http.post('rest/getOffLtrYear').error(function(data) {

	}).success(
			function(data) {

				if (data[0] == "NoLetter") {
					$scope.noLetter = true;
				}

				else {
					$scope.COUNTRY = "India";
					if (data.min == 1 && data.max == 1) {
						$('#loading').hide();
						$scope.noLetter = !$scope.noLetter;
					} else {
						var temp = new Date();
						temp.setFullYear(parseInt((data.min.toString())
								.substring(0, 4)));
						mindate = new Date(temp);
						temp.setFullYear(parseInt((data.max.toString())
								.substring(0, 4)));
						maxdate = new Date(temp);
						maxyear = (data.max.toString()).substring(0, 4) + "-"
								+ (data.max.toString()).substring(4);
						datepicker.datepicker('remove');

						datepicker.children().first().val(maxyear);
						datepicker.datepicker({
							format : "yyyy-yyyy",
							startView : "years",
							minViewMode : "years",
							orientation : 'right',
							startDate : mindate,
							endDate : maxdate,
							orientation : 'right',
							autoclose : true
						});

						// letterlist
						$('#finyear').val(datepicker.children().first().val());
						$scope.offLtr.year = $('#finyear').val();
						$http.post('rest/getOffclLetterList', $scope.offLtr)
								.error(function(data) {

								}).success(function(data) {

									$('#loading').hide();
									if (data[0] == 'NoLetter') {
										$scope.noLetter = !$scope.noLetter;
									} else {
										$scope.offLtr.letterName = data[0];
										$scope.letterList = data;
									}
								});

					}
				}

			});

	// Call on Change of Year
	$('#datepickerfy').datepicker().on(
			'changeDate',
			function(ev) {

				$scope.offLtr.country = $scope.COUNTRY;
				$scope.offLtr.year = $('#finyear').val();
				$scope.monthList = 0;
				$http.post('rest/getOffclLetterList', $scope.offLtr).error(
						function(data) {

						}).success(function(data) {

					$('#loading').hide();
					$scope.offLtr.letteName = data[0];
					$scope.letterList = data;
				});

			});

	// Call On Change of Country
	$scope.changeCountry = function() {
		$scope.offLtr.country = $scope.COUNTRY;
		$scope.offLtr.year = $('#finyear').val();

		$http.post('rest/getOffclLetterList', $scope.offLtr).error(
				function(data) {

				}).success(function(data) {

			$('#loading').hide();
			$scope.letterList = data;
			$scope.offLtr.letterName = data[0];
		});

	};

	// PDF generation

	$scope.getOfficialLetter = function(letter) {

		$scope.offLtr.letterName = letter;

		$scope.temp_year = $scope.offLtr.year.replace("-", "");

		doc = {};
		doc.letterType = letter + '-' + $scope.offLtr.year;
		$http.post('rest/userLog', doc).error(function(data) {
			$('#loading').hide();
		}).success(function(data) {
		});

		if ($scope.offLtr.letterName == "TCS Confirmation Letter") {
			$('#loading').show();
			$http.post('rest/callJSPPage', $scope.offLtr).error(function() {

			}).success(function() {
				$('#loading').hide();
				$scope.modalPopupComp("pages/TCSHRConf.jsp", "tcshrconf.jsp");

			});

		}

		else {
			$('#loading').show();
			$http
					.post('rest/checkAvail', $scope.offLtr)
					.error(function(data) {

					})
					.success(
							function(data) {

								if (data[0] == 1) {
									$scope.showpopup = false;

									$http
											.post('rest/getOffLtrPdf',
													$scope.offLtr)
											.error(function(data) {
											})
											.success(
													function(data, response) {
														var fileURL = '';
														if (!IsSafari()) {
															var byteCharacters = atob(data.bytes);
															var byteNumbers = new Array(
																	byteCharacters.length);
															for ( var i = 0; i < byteCharacters.length; i++) {
																byteNumbers[i] = byteCharacters
																		.charCodeAt(i);
															}
															var byteArray = new Uint8Array(
																	byteNumbers);
															var inFile = new Blob(
																	[ byteArray ],
																	{
																		type : "application/pdf"
																	});
															inFile = blobToFile(
																	inFile,
																	data.fileName);
															fileURL = URL
																	.createObjectURL(inFile);
														}
														var message = data.message;
														$('#loading').hide();
														// new code for modal
														// popup start
														var modinst = $modal
																.open({
																	windowClass : "modal fade in",
																	animation : true,
																	backdrop : 'static',
																	templateUrl : 'pages/OffLtrContent.html' +'?cd='+ (new Date()).getTime(),
																	controller : function(
																			$scope,
																			$http) {
																		$scope.fileObject = {};
																		$scope.fileObject.fileUrl = fileURL;
																		$scope.fileObject.name = data.fileName;
																		$scope.fileObject.message = message;
																		$scope.fileObject.savebutton = true;
																		$scope.fileObject.printbutton = true;
																		if (window.navigator
																				&& window.navigator.msSaveOrOpenBlob) {
																			$scope.fileObject.printbutton = false;
																		}
																		if (IsSafari()) {
																			$scope.fileObject.savebutton = false;
																			$scope.fileObject.printbutton = false;
																		}

																		$scope.close = function() {
																			modinst
																					.dismiss('cancel');
																			URL
																					.revokeObjectURL(fileURL);

																		};
																		$scope.print = function() {
																			printfile(fileURL);
																		};
																		$scope.download = function() {
																			saveData(
																					inFile,
																					data.fileName);
																		};
																	}
																});
														// new code for modal
														// popup end

														$http
																.post(
																		'rest/checkAcceptance',
																		$scope.offLtr)
																.error(
																		function(
																				data) {

																		})
																.success(
																		function(
																				data) {
																			if (data[0] == 1) {
																				$(
																						'#pdfAccept')
																						.hide();

																			} else if (data[0] == 0) {

																				$(
																						'#pdfAccept')
																						.show();
																				$('#mbody').removeClass('mbodyfull');
																				$('#mbody').addClass('mbodyhalf');
																				
																			}
																		});

													});

								} else if (data[0] == 0) {

									$('#loading').hide();
									// $scope.showpopup = true;
									var modinst = $modal
											.open({
												windowClass : "modal fade in",
												animation : true,
												backdrop : 'static',
												templateUrl : 'pages/OffLtrBPOContent.html',
												controller : function($scope,
														$http) {

													$scope.close = function() {
														modinst
																.dismiss('cancel');

													};

												}
											});
								}

							});

		}

	};

	$scope.acceptLetter = function() {

		$http.post('rest/updateFlag', $scope.offLtr).error(function(data) {

		}).success(function(data) {

			if (data[0] == 1) {
				$('#pdfAccept').hide();
				$('#acceptedID').show();
				$('#mbody').addClass('mbodyhalf');
				$('#mbody').removeClass('mbodyfull');
			} else if (data[0] == 0) {
				$('#pdfAccept').show();
				$('#acceptedID').hide();
				$('#mbody').removeClass('mbodyhalf');
				$('#mbody').addClass('mbodyfull');
			}
		});
	};

	$scope.modalPopupComp = function(fileURL, fileName) {

		// new code for modal popup start
		var modinst = $modal.open({
			windowClass : "modal fade in",
			animation : true,
			backdrop : 'static',
			templateUrl : 'pages/modalContent.html' +'?cd='+ (new Date()).getTime(),
			controller : function($scope, $http) {
				$scope.fileObject = {};
				$scope.fileObject.fileUrl = fileURL;
				$scope.fileObject.name = fileName;
				$scope.fileObject.savebutton = false;
				$scope.fileObject.printbutton = true;
				if (window.navigator && window.navigator.msSaveOrOpenBlob) {
					$scope.fileObject.printbutton = false;
				}
				if (IsSafari()) {
					$scope.fileObject.savebutton = false;
					$scope.fileObject.printbutton = false;
				}

				$scope.close = function() {
					modinst.dismiss('cancel');
					URL.revokeObjectURL(fileURL);
					//
				};
				$scope.print = function() {
					printfile(fileURL);
				};
				$scope.download = function() {
					saveData(inFile, data.fileName);
				};
			}
		});
		// new code for modal popup end

	};

}