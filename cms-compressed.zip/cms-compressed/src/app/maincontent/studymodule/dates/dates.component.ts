import { Component,ViewChild} from '@angular/core';
import { MatTableDataSource,MatPaginator,MatSort } from '@angular/material';
import {Http,Response } from '@angular/http';
import { DatesService } from './dates.service';
import { LoadingModule,ANIMATION_TYPES } from 'ngx-loading';


@Component({
  selector: 'study-dates',
  templateUrl: './dates.html'
})
export class DatesComponent {

  displayedDateColumns = ['Date Type','Scheduled Start','Project Start','Actual Start',
  'Scheduled End','Project End','Actual End','Client','Comments','Delete' ];

  displayedDateDetailsColumns = ['Detail', 'Value','Comments'];
 
  datesDataSource;
  dates=[];
  dateDetails=[];
  datesDetailDataSource
  datesDataSourceLength:number=0;
  datesDetailDataSourceLength:number=0;
  public datesLoader = false;

  @ViewChild('datesPaginator') datesPaginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @ViewChild('datesDetailPaginator') datesDetailPaginator: MatPaginator;
 @ViewChild(MatSort) datesDetailSort: MatSort;
  
  constructor(private _datesService:DatesService){} 


  setDatesDataSource(res)
  {
    this.dates=res;
    this.datesDataSource = new MatTableDataSource(res);
    this.datesDataSource.paginator = this.datesPaginator;
    this.datesDataSource.sort = this.sort;
    this.datesDataSourceLength=this.datesDataSource.data.length;

    this.datesDetailDataSource = new MatTableDataSource(res);
    this.datesDetailDataSource.paginator = this.datesDetailPaginator;
    this.datesDetailDataSource.sort = this.datesDetailSort;
    this.datesDetailDataSourceLength=this.datesDetailDataSource.data.length;
  
  }
  
  applyDateFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.datesDataSource.filter = filterValue;
  } 
  applyDateDetailsFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.datesDetailDataSource.filter = filterValue;
  } 

  changeDateDetails(date)
  {
    console.log(date);
    this.dateDetails=this.dates.filter(dateDetail=>dateDetail.DTRowid===date);
    this.datesDetailDataSource = new MatTableDataSource(this.dateDetails);
    this.datesDetailDataSource.paginator = this.datesDetailPaginator;
    this.datesDetailDataSource.sort = this.datesDetailSort;


  }
  getDates(studyNumber:string,phaseRowId:string)
  {
    this.datesLoader = true;
    this._datesService.getDates(studyNumber, phaseRowId).subscribe(res=>{
      this.datesLoader = false;
      this.setDatesDataSource(res)});
  }

  onReset()
  {
    this.datesDataSource=null;
    this.datesDataSourceLength=0;
    this.datesDetailDataSourceLength=0;
    this.datesDetailDataSource=null;
    
  }

}

