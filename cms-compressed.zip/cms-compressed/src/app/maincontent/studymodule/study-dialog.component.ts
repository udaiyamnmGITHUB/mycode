import {Component, Inject} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

@Component({
  selector: 'study-dialog',
  templateUrl: 'study-dialog.html',
  styleUrls: ['study-dialog.css']
})
export class StudyDialog {

  constructor(
    public dialogRef: MatDialogRef<StudyDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
