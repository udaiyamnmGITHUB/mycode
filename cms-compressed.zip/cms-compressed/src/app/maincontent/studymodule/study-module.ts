import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { TextMaskModule } from 'angular2-text-mask';
import { AppMaterialModule } from '../../app-material.module';
import { AppRoutingModule }      from '../../app-routing.module';
import { LoadingModule,ANIMATION_TYPES } from 'ngx-loading';
import { FormGroup, FormBuilder,FormControl, Validators } from '@angular/forms';
import { StudyComponent } from './study.component';
import { StudyDetailComponent } from '../../maincontent/studymodule/study-details/study-detail.component';
import { AgencyGuideComponent } from '../../maincontent/studymodule/agency-guide/agency-guide.component';
import { PhaseComponent } from '../../maincontent/studymodule/phase/phase.component';
import { DatesComponent } from '../../maincontent/studymodule/dates/dates.component';
import { PersonnelComponent } from '../../maincontent/studymodule/personnel/personnel.component';
import { UnderDevComponent } from '../underdev.component';
import { NotAuthorised } from '../auth.component';
import { ReportsComponent } from '../../maincontent/reportsmodule/reports.component';

import { StudyService } from '../../maincontent/studymodule/study.service';
import { PhaseService } from '../../maincontent/studymodule/phase.service';
import { PersonnelService } from '../../maincontent/studymodule/personnel/personnel.service';
import { AgencyGuideService } from './agency-guide/agency-guide.service';
import { DatesService } from './dates/dates.service';
import { ReportsService } from '../reportsmodule/reports-service';
import { AppComponent } from '../../app.component';
import { DialogOverviewExampleDialog} from '../../dialog.component';
import {StudyDialog } from './study-dialog.component';

@NgModule({
    declarations: [       
        StudyDetailComponent,
        AgencyGuideComponent,
        PhaseComponent,
        DatesComponent,
        PersonnelComponent,
        StudyComponent,
        UnderDevComponent,
        NotAuthorised,
        ReportsComponent ,
        DialogOverviewExampleDialog,
        StudyDialog           
    ],
    imports: [
        CommonModule,
        HttpModule,
        FormsModule,
        ReactiveFormsModule,
        TextMaskModule,
        AppRoutingModule,
        AppMaterialModule,
        LoadingModule
    ],
    entryComponents: [ DialogOverviewExampleDialog,StudyDialog ],
    providers: [StudyService, PhaseService, PersonnelService,AgencyGuideService,DatesService,ReportsService],
})
export class StudyModule { }


