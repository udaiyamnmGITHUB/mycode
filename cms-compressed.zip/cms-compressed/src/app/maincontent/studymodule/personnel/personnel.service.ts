import { Http, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AppConstants } from '../../../app-constants';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class PersonnelService {
    constructor(private http: Http) { }
    getPersonnel(studyNumber) {
        return this.http.get(AppConstants.PERSONNEL_URL+'studyCode='+studyNumber)
            .map((response: Response) => response.json())
            .catch((responseError: Response) => Observable.throw(this.errorHandler(responseError)));
    }
    errorHandler(responseError: Response) {
        console.log(responseError);
        Observable.throw(responseError != null ? responseError : 'Server Error');
    }
}