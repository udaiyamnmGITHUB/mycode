import { Component, OnInit, ViewChild, Directive, Output, Input, EventEmitter } from '@angular/core';
import { StudyService } from './study.service';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA,MatDialogModule } from '@angular/material';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { AppConstants } from '../../app-constants';
import { Globals } from '../../globals';
import { FormGroup, FormBuilder,FormControl, Validators } from '@angular/forms';
import {StudyDialog } from './study-dialog.component';

declare var $: any;

@Component({
  selector: 'study',
  templateUrl: './study.html'
})

export class StudyComponent {
  //Viewchild declaration
  @ViewChild('studyDetail') studyDetailChild;
  @ViewChild('phaseDetail') phaseDetailChild;
  @ViewChild('personnelDetail') personnelDetail;
  @ViewChild('agencyGuideDetail') agencyGuideDetail;
  @ViewChild('dateDetail') dateDetail;
    //Variable declaration
  phaseDDValue;
  _studyNum="";
  _CompoundId="";
  _AssayMod="";
  _title="";
  _clientId="";
  _clientName="";
  _financialId="";
 
  
  
  clientDetails = [];  
  studyDetails = [];
  studyDetailsDD = [];
  phaseValuesDD = [];
  studyNumberDD = [];
  studyNumberValue;
  butDisabled: boolean = false;
  showStudyDropdown: boolean = true;
  disableRetrieve: boolean = false;
  prevLength;
  nextLength;

  studyVal:FormGroup;
  //Regex for studynumber
  mask = [/[a-zA-Z0-9]/, /[a-zA-Z0-9]/, /[a-zA-Z0-9]/, /[a-zA-Z0-9]/, '-', /[a-zA-Z0-9]/, /[a-zA-Z0-9]/, /[a-zA-Z0-9]/];
  public studyloader = false;
  
  constructor(private _studySevice: StudyService, public dialog: MatDialog, public _globals:Globals) { }

  ngOnInit() {
    
    this.studyVal = new FormGroup({
      _studyNum: new FormControl('', [
        
         Validators.minLength(4),
         Validators.required
         
         
       ]),
       _title: new FormControl('', [
        
         Validators.minLength(4),
         Validators.maxLength(20),
         Validators.required
         
       ]),
       _clientId: new FormControl('', [
        
         Validators.minLength(4),
         Validators.required
       ]),
       _financialId: new FormControl('', [
        
         Validators.minLength(4),
         Validators.required
       ]),
       _CompoundId:new FormControl('', [
               
       ]),
       _AssayMod:new FormControl('', [
        ]),
        _clientName:new FormControl('', [
          
          ]),
        phaseDDValue:new FormControl('', [
            
            ])
       
     });

  }
  
//To call the childern's method on studynumber click
  @Output()
  emitEvent = new EventEmitter();

  changePhaseDetails(phase:any) {
    let studyNum=this._studyNum;
    this.phaseDetailChild.getPhase(studyNum, phase.phaserowid);
    this.dateDetail.getDates(this._studyNum, phase.phaserowid);
  }
  getStudy(clientId,financialId,title) {
    debugger;
    this.studyloader = true;
    this.butDisabled = true;
    this._studySevice.getStudyNumbers(this._studyNum, this._clientId, this._financialId, this._title).subscribe(resStudyDD => {
      this.studyloader = false;
      var self = this;
      setTimeout(function(){
        self.setStudyDDValues(resStudyDD)
      }, 100);
      
    });
  }
  setPhase(res:any, studyNumber) { 
   
    this.phaseValuesDD = res;
    this.phaseDDValue =  this.phaseValuesDD.length>0?this.phaseValuesDD[0].phaserowid:"";
    this.phaseDetailChild.getPhase(studyNumber, this.phaseDDValue);
    this.dateDetail.getDates(studyNumber, this.phaseDDValue);

  }
  setStudyDDValues(resStudyDD) {
  
    this._studyNum = resStudyDD.length>0?resStudyDD[0].StudyId:"";
    this._globals.numOfStudy=resStudyDD.length;
    //For proper study number
    if (resStudyDD.length == 1) {
      
      this.showStudyDropdown = true;
      this.studyNumberDD = resStudyDD;
      this._studySevice.getStudyDetails(this._studyNum).subscribe(resStudy => this.setStudyDetails(resStudy));
      this.studyDetailChild.getStudyDetails(this._studyNum);
    }
    //For partial search on study number
    else {
      this.showStudyDropdown = false;
      this.studyNumberDD = resStudyDD;
      this._studySevice.getStudyDetails(this._studyNum).subscribe(resStudy => this.setStudyDetails(resStudy));
      this.studyDetailChild.getStudyDetails(this._studyNum);
    }
   
    this._studySevice.getPhaseValues(this._studyNum).subscribe(resPhaseValues => this.setPhase(resPhaseValues, this._studyNum));
    this.personnelDetail.getPersonnel(this._studyNum);
    this.agencyGuideDetail.getAgencyGuide(this._studyNum);
  }
  setStudyDetails(resStudyDetails) {
    this.studyDetails =resStudyDetails.length>0?resStudyDetails[0]:"";
    this._title=resStudyDetails.length>0?resStudyDetails[0].Title:"";
    this._clientId=resStudyDetails.length>0?resStudyDetails[0].clid:""; 
    this._financialId=resStudyDetails.length>0?resStudyDetails[0].FinancialClientID:"";
    this._CompoundId=resStudyDetails.length>0?resStudyDetails[0].CompoundId:"";
    this._AssayMod=resStudyDetails.length>0?resStudyDetails[0].AssayMod:"";
    this._clientName=resStudyDetails.length>0?resStudyDetails[0].Client_Name:"";
    this.studyDetailsDD = resStudyDetails;
  }
  getStudyDetails(studyNumber:any) {
    
    this._studySevice.getStudyDetails(studyNumber.StudyId).subscribe(resStudy => this.setStudyDetails(resStudy));
    this._studySevice.getPhaseValues(studyNumber.StudyId).subscribe(resPhaseValues => this.setPhase(resPhaseValues,studyNumber.StudyId));
  }

  onChange(newValue) {
   
    this._studyNum = newValue.StudyId;
    this.getStudyDetails(newValue)
  }
  changeNext(){
    var val=this.studyNumberDD.findIndex(o=>o.StudyId==this._studyNum);
    if((val+1<this.studyNumberDD.length ))
    {
    val=val+1;
    this._studyNum=this.studyNumberDD[val];
    this.onChange(this._studyNum); 
      
    }


  }

  changePrev(){
    var val=this.studyNumberDD.findIndex(o=>o.StudyId==this._studyNum);
    
    if(val>0)
    {
      val=val-1;
      this._studyNum=this.studyNumberDD[val];
    this.onChange(this._studyNum);
    }

  }

  onReset()
  {
    //window.location.reload();
    
    this.studyVal.reset();
 
    this._studyNum="";
    this._clientId="";
    this._financialId="";
    this._title="";
    this.phaseValuesDD = null;
    this.showStudyDropdown = true;
    this._globals.numOfStudy=0;
    this.studyDetailChild.onReset();
    this.agencyGuideDetail.onReset();
    this.phaseDetailChild.onReset();
    this.dateDetail.onReset();
    this.personnelDetail.onReset();
  }

  generateReport()
  {
    let dialogRef = this.dialog.open(StudyDialog, {
      width: '500px',
      //data: { name: 'this.name', animal: 'this.anima' }
      
    });
  }

}


