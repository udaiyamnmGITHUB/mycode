import { Component } from '@angular/core';

@Component({
  template: `<section class="content-header">

  <h1>
    you are not authorised to see this page
  </h1>
  <img src="../assets/img/login/Not-Authorised.png">

</section>`
})
export class NotAuthorised {

}
